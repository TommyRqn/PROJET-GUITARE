﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace CLIENT
{
    public partial class MainPage : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public MainPage()
        {
            InitializeComponent();
        }

        public void On_btnLogin_Click(object P_Sender, EventArgs P_Arg)
        {
            List<NS_WS.C_CLIENT> Un_Client = new List<NS_WS.C_CLIENT>();
            if(entEmail.Text != "" && entPassword.Text != "")
            {
                foreach(NS_WS.C_CLIENT Le_Client in Le_WS.Login(entEmail.Text, entPassword.Text))
                {
                    Un_Client.Add(Le_Client);
                }

                if (Un_Client.Any())
                {
                    Application.Current.MainPage = new Views.MenuListe(Un_Client[0].idClient);
                }
            }
        }

        public void On_btnInscription_Click(object P_Sender, EventArgs P_Arg)
        {
            Navigation.PushModalAsync(new Views.Inscription());
        }
    }
}

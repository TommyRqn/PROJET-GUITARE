﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CLIENT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MenuListe : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);
        static List<NS_WS.C_CLIENT> Le_Client = new List<NS_WS.C_CLIENT>();
        static List<NS_WS.C_BOIS> Les_Bois = new List<NS_WS.C_BOIS>();
        static List<NS_WS.C_MICROPHONE> Les_Microphones = new List<NS_WS.C_MICROPHONE>();
        static List<NS_WS.C_VIBRATO> Les_Vibratos = new List<NS_WS.C_VIBRATO>();
        static int nbMicro = 0;

        public MenuListe(int P_Id)
        {
            InitializeComponent();
            foreach(NS_WS.C_CLIENT client in Le_WS.Get_Client_By_Id(P_Id))
            {
                Le_Client.Add(client);
            }

            foreach (NS_WS.C_BOIS bois in Le_WS.Get_All_Bois())
            {
                Les_Bois.Add(bois);
            }
            Les_Bois.RemoveAll(r => r.Stock == 0);

            foreach (NS_WS.C_MICROPHONE microphone in Le_WS.Get_All_Microphone())
            {
                Les_Microphones.Add(microphone);
            }
            var microAucunRemove = Les_Microphones.Single(r => r.idMicrophone == 1);
            Les_Microphones.Remove(microAucunRemove);
            Les_Microphones.RemoveAll(r => r.Stock == 0);

            foreach (NS_WS.C_VIBRATO vibrato in Le_WS.Get_All_Vibrato())
            {
                Les_Vibratos.Add(vibrato);
            }
            Les_Vibratos.RemoveAll(r => r.Stock == 0);

            BoisManche.ItemsSource = Les_Bois;
            BoisCorps.ItemsSource = Les_Bois;
            BoisTouche.ItemsSource = Les_Bois;
            MicroNeck.ItemsSource = Les_Microphones;
            MicroCentrale.ItemsSource = Les_Microphones;
            MicroBridge.ItemsSource = Les_Microphones;
            VibratoGuitare.ItemsSource = Les_Vibratos;
        }

        public void btnCommanderClick(object P_Sender, EventArgs P_Arg)
        {
            if(entNomGuitare.Text != "" && VibratoGuitare.SelectedIndex != -1 && BoisManche.SelectedIndex != -1 && BoisCorps.SelectedIndex != -1 && BoisTouche.SelectedIndex != -1)
            {
                if (MicroBridge.SelectedIndex != -1)
                {
                    nbMicro++;
                }
                if (MicroCentrale.SelectedIndex != -1)
                {
                    nbMicro++;
                }
                if (MicroNeck.SelectedIndex != -1)
                {
                    nbMicro++;
                }
                if(nbMicro>1)
                {
                    if (MicroNeck.SelectedIndex == -1)
                    {
                        Le_WS.Add_Guitare_No_Neck(entNomGuitare.Text, 
                            ((NS_WS.C_MICROPHONE)MicroCentrale.SelectedItem).idMicrophone, 
                            ((NS_WS.C_VIBRATO)VibratoGuitare.SelectedItem).idVibrato, 
                            Le_Client[0].idClient,
                            ((NS_WS.C_MICROPHONE)MicroBridge.SelectedItem).idMicrophone,
                            ((NS_WS.C_BOIS)BoisManche.SelectedItem).idBois,
                            ((NS_WS.C_BOIS)BoisCorps.SelectedItem).idBois,
                            ((NS_WS.C_BOIS)BoisTouche.SelectedItem).idBois);
                        DisplayAlert("REUSSIE", "Commande réussie", "ok");
                        nbMicro = 0;
                    }
                    else if (MicroCentrale.SelectedIndex == -1)
                    {
                        Le_WS.Add_Guitare_No_Centrale(entNomGuitare.Text,
                            ((NS_WS.C_MICROPHONE)MicroNeck.SelectedItem).idMicrophone,
                            ((NS_WS.C_VIBRATO)VibratoGuitare.SelectedItem).idVibrato,
                            Le_Client[0].idClient,
                            ((NS_WS.C_MICROPHONE)MicroBridge.SelectedItem).idMicrophone,
                            ((NS_WS.C_BOIS)BoisManche.SelectedItem).idBois,
                            ((NS_WS.C_BOIS)BoisCorps.SelectedItem).idBois,
                            ((NS_WS.C_BOIS)BoisTouche.SelectedItem).idBois);
                        DisplayAlert("REUSSIE", "Commande réussie", "ok");
                        nbMicro = 0;
                    }
                    else if (MicroBridge.SelectedIndex == -1)
                    {
                        Le_WS.Add_Guitare_No_Bridge(entNomGuitare.Text,
                            ((NS_WS.C_MICROPHONE)MicroNeck.SelectedItem).idMicrophone,
                            ((NS_WS.C_MICROPHONE)MicroCentrale.SelectedItem).idMicrophone,
                            ((NS_WS.C_VIBRATO)VibratoGuitare.SelectedItem).idVibrato,
                            Le_Client[0].idClient,
                            ((NS_WS.C_BOIS)BoisManche.SelectedItem).idBois,
                            ((NS_WS.C_BOIS)BoisCorps.SelectedItem).idBois,
                            ((NS_WS.C_BOIS)BoisTouche.SelectedItem).idBois);
                        DisplayAlert("REUSSIE", "Commande réussie", "ok");
                        nbMicro = 0;
                    }
                    else
                    {
                        Le_WS.Add_Guitare(entNomGuitare.Text, 
                            ((NS_WS.C_MICROPHONE)MicroNeck.SelectedItem).idMicrophone, 
                            ((NS_WS.C_MICROPHONE)MicroCentrale.SelectedItem).idMicrophone, 
                            ((NS_WS.C_VIBRATO)VibratoGuitare.SelectedItem).idVibrato, 
                            Le_Client[0].idClient,
                            ((NS_WS.C_MICROPHONE)MicroBridge.SelectedItem).idMicrophone,
                            ((NS_WS.C_BOIS)BoisManche.SelectedItem).idBois,
                            ((NS_WS.C_BOIS)BoisCorps.SelectedItem).idBois,
                            ((NS_WS.C_BOIS)BoisTouche.SelectedItem).idBois);
                        DisplayAlert("REUSSIE", "Commande réussie", "ok");
                        nbMicro = 0;
                    }
                }
                else
                {
                    DisplayAlert("ERREUR", $"Seulement {nbMicro} micro est choisi, 2 ou 3 micros minimum sont requis !", "ok");
                    nbMicro = 0;
                }
            }
            else
            {
                DisplayAlert("ERREUR", "Vous devez remplir tous les champs et au moins 2 microphones sur 3 !", "ok");
                nbMicro = 0;
            }
            entNomGuitare.Text = null;
            BoisCorps.SelectedIndex = -1;
            BoisManche.SelectedItem = -1;
            BoisTouche.SelectedItem = -1;
            MicroBridge.SelectedItem = -1;
            MicroCentrale.SelectedItem = -1;
            MicroNeck.SelectedItem = -1;
            VibratoGuitare.SelectedItem = -1;

        }

        public void btnMesCommandesClick(object P_Sender, EventArgs P_Arg)
        {
            Navigation.PushModalAsync(new MesCommandes(Le_Client[0].idClient));
        }
    }
}
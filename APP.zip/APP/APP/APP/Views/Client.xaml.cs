﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Client : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);
        static List<NS_WS.C_CLIENT> Les_Clients = new List<NS_WS.C_CLIENT>();

        public Client()
        {
            InitializeComponent();

            foreach (NS_WS.C_CLIENT item in Le_WS.Get_All_Client())
            {
                Les_Clients.Add(item);
            }

            Task.Factory.StartNew(() =>
            {
                ListeClients.ItemsSource = Les_Clients;
            });
        }

        private async void OnItemSelected(Object sender, ItemTappedEventArgs e)
        {
            var details = e.Item as NS_WS.C_CLIENT;
            await Navigation.PushAsync(new DetailClient(Convert.ToString(details.idClient)));
        }
    }
}
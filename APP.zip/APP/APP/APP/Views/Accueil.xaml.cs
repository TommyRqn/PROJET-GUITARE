﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Accueil : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        static List<NS_WS.C_GUITARE> Les_Guitares = new List<NS_WS.C_GUITARE>();

        public Accueil()
        {
            InitializeComponent();
        }

        public void On_btnChercherClient_Click(object P_Sender, EventArgs P_Arg)
        {
            if (entNomClient.Text != "" && entPrenomClient.Text != "")
            {
                GuitaresClient.ItemsSource = null;
                Les_Guitares.Clear();

                foreach (NS_WS.C_GUITARE item in Le_WS.Get_Guitare_Nom_Prenom(entNomClient.Text, entPrenomClient.Text))
                {
                    Les_Guitares.Add(item);
                }

                GuitaresClient.ItemsSource = Les_Guitares;

                entNomClient.Text = null;
                entPrenomClient.Text = null;
            }
        }

        private async void OnItemSelected(Object sender, ItemTappedEventArgs e)
        {
            var details = e.Item as NS_WS.C_GUITARE;
            await Navigation.PushAsync(new DetailReservation(Convert.ToString(details.idMicrophone_Neck), Convert.ToString(details.idMicrophone_Centrale), Convert.ToString(details.idVibrato), Convert.ToString(details.idClient), Convert.ToString(details.idMicrophone_Bridge), Convert.ToString(details.idBois_Manche), Convert.ToString(details.idBois_Corps), Convert.ToString(details.idBois_Touche)));
        }

    }
}
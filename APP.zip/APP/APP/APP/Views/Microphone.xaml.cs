﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Microphone : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        static List<NS_WS.C_MICROPHONE> Les_Microphones = new List<NS_WS.C_MICROPHONE>();

        public Microphone()
        {
            InitializeComponent();

            foreach (NS_WS.C_MICROPHONE item in Le_WS.Get_All_Microphone())
            {
                Les_Microphones.Add(item);
            }

            Task.Factory.StartNew(() =>
            {
                ListeMicrophone.ItemsSource = Les_Microphones;
            });
        }

        public void On_btnAjoutMicrophone_Click(object P_Sender, EventArgs P_Arg)
        {
            if (entNomMicro.Text != "" && entReferenceMicro.Text != "" && entMarqueMicro.Text != "" && entMarqueMicro.Text != "")
            {
                Les_Microphones.Clear();
                ListeMicrophone.ItemsSource = null;
                Le_WS.Add_Microphone(entNomMicro.Text, entReferenceMicro.Text, entMarqueMicro.Text, Int32.Parse(entStockMicro.Text));

                foreach (NS_WS.C_MICROPHONE item in Le_WS.Get_All_Microphone())
                {
                    Les_Microphones.Add(item);
                }

                ListeMicrophone.ItemsSource = Les_Microphones;
            }
            entNomMicro.Text = null;
            entReferenceMicro.Text = null;
            entMarqueMicro.Text = null;
            entStockMicro.Text = null;
        }

        private async void OnItemSelected(Object sender, ItemTappedEventArgs e)
        {
            var details = e.Item as NS_WS.C_MICROPHONE;
            await Navigation.PushAsync(new DetailMicrophone(details.idMicrophone, details.Nom, details.Reference_Construceteur, details.Marque, Convert.ToString(details.Stock)));
        }

        public void RefreshView(System.Object sender, System.EventArgs e)
        {
            ICommand refreshCommand = new Command(() =>
            {
                // IsRefreshing is true
                // Refresh data here
                Les_Microphones.Clear();
                ListeMicrophone.ItemsSource = null;

                foreach (NS_WS.C_MICROPHONE item in Le_WS.Get_All_Microphone())
                {
                    Les_Microphones.Add(item);
                }

                ListeMicrophone.ItemsSource = Les_Microphones;

                rView.IsRefreshing = false;
            });
            rView.Command = refreshCommand;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DetailBois : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public DetailBois(int P_idBois, string P_Nom, string P_Origine, string P_Stock)
        {
            InitializeComponent();
            entNomBois.Text = P_Nom;
            entOrigineBois.Text = P_Origine;
            entStockBois.Text = P_Stock;
            lbIdBois.Text = Convert.ToString(P_idBois);
        }

        public void On_btnEditer_Click(object P_Sender, EventArgs P_Arg)
        {
            Task.Factory.StartNew(() =>
            {
                if (entNomBois.Text != "" && entOrigineBois.Text != "" && entOrigineBois.Text != "")
                {
                    Le_WS.Edit_Bois(Int32.Parse(lbIdBois.Text), entNomBois.Text, entOrigineBois.Text, Int32.Parse(entStockBois.Text));
                    Navigation.PopAsync();
                }
            });
        }
    }
}
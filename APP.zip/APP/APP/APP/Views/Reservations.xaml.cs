﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Reservations : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        static List<NS_WS.C_GUITARE> Les_Guitares = new List<NS_WS.C_GUITARE>();
        static List<NS_WS.C_GUITARE> Ses_Guitares_Fini = new List<NS_WS.C_GUITARE>();

        public Reservations()
        {
            InitializeComponent();

            foreach (NS_WS.C_GUITARE item in Le_WS.Get_All_Guitare())
            {
                Les_Guitares.Add(item);
                Ses_Guitares_Fini.Add(item);
            }
            Les_Guitares.RemoveAll(r => r.Etat == "Terminé");
            Ses_Guitares_Fini.RemoveAll(r => r.Etat == "En cours");

            Task.Factory.StartNew(() =>
            {
                ListeGuitare.ItemsSource = Les_Guitares;
                ListesGuitaresFini.ItemsSource = Ses_Guitares_Fini;
            });
        }

        private async void OnItemSelected(Object sender, ItemTappedEventArgs e)
        {
            var details = e.Item as NS_WS.C_GUITARE;
            await Navigation.PushAsync(new DetailReservation(Convert.ToString(details.idMicrophone_Neck), Convert.ToString(details.idMicrophone_Centrale), Convert.ToString(details.idVibrato), Convert.ToString(details.idClient), Convert.ToString(details.idMicrophone_Bridge), Convert.ToString(details.idBois_Manche), Convert.ToString(details.idBois_Corps), Convert.ToString(details.idBois_Touche)));
        }

        public void RefreshView(System.Object sender, System.EventArgs e)
        {
            ICommand refreshCommand = new Command(() =>
            {
                // IsRefreshing is true
                // Refresh data here
                ListeGuitare.ItemsSource = null;
                Les_Guitares.Clear();

                foreach (NS_WS.C_GUITARE item in Le_WS.Get_All_Guitare())
                {
                    Les_Guitares.Add(item);
                }
                ListeGuitare.ItemsSource = Les_Guitares;

                rView.IsRefreshing = false;
            });
            rView.Command = refreshCommand;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DetailMicrophone : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public DetailMicrophone(int P_idMicro, string P_Nom, string P_Reference, string P_Marque, string P_Stock)
        {
            InitializeComponent();
            entNomMicro.Text = P_Nom;
            entReferenceMicro.Text = P_Reference;
            entMarqueMicro.Text = P_Marque;
            entStockMicro.Text = P_Stock;
            lbIdMicro.Text = Convert.ToString(P_idMicro);
        }

        public void On_btnEditer_Click(object P_Sender, EventArgs P_Arg)
        {
            Task.Factory.StartNew(() =>
            {
                if (entNomMicro.Text != "" && entReferenceMicro.Text != "" && entMarqueMicro.Text != "" && entMarqueMicro.Text != "")
                {
                    Le_WS.Edit_Microphone(Int32.Parse(lbIdMicro.Text), entNomMicro.Text, entReferenceMicro.Text, entMarqueMicro.Text, Int32.Parse(entStockMicro.Text));
                    Navigation.PopAsync();
                }
            });
        }
    }
}
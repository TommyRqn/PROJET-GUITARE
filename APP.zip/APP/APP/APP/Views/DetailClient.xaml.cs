﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DetailClient : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public DetailClient(string P_Id)
        {
            InitializeComponent();

            List<NS_WS.C_GUITARE> Ses_Guitares = new List<NS_WS.C_GUITARE>();

            foreach (NS_WS.C_GUITARE item in Le_WS.Get_Guitare_By_Client_Id(Int32.Parse(P_Id)))
            {
                Ses_Guitares.Add(item);
            }

            Task.Factory.StartNew(() =>
            {
                ListesGuitares.ItemsSource = Ses_Guitares;
            });
        }

        private async void OnItemSelected(Object sender, ItemTappedEventArgs e)
        {
            var details = e.Item as NS_WS.C_GUITARE;
            await Navigation.PushAsync(new DetailReservation(Convert.ToString(details.idMicrophone_Neck), Convert.ToString(details.idMicrophone_Centrale), Convert.ToString(details.idVibrato), Convert.ToString(details.idClient), Convert.ToString(details.idMicrophone_Bridge), Convert.ToString(details.idBois_Manche), Convert.ToString(details.idBois_Corps), Convert.ToString(details.idBois_Touche)));
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DetailClientAccueil : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public DetailClientAccueil(string P_Id)
        {
            InitializeComponent();

            List<NS_WS.C_CLIENT> Le_Client = new List<NS_WS.C_CLIENT>();

            foreach (NS_WS.C_CLIENT item in Le_WS.Get_Client_By_Id(Int32.Parse(P_Id)))
            {
                Le_Client.Add(item);
            }

            Task.Factory.StartNew(() =>
            {
                ListeClient.ItemsSource = Le_Client;
            });
        }
    }
}
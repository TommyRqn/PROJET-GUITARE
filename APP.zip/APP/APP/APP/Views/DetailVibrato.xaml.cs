﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DetailVibrato : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        public DetailVibrato(int P_idVibrato, string P_Nom, string P_Modele, string P_Marque, string P_Stock)
        {
            InitializeComponent();
            entNomVibrato.Text = P_Nom;
            entModeleVibrato.Text = P_Modele;
            entMarqueVibrato.Text = P_Marque;
            entStockMicro.Text = P_Stock;
            lbIdVibrato.Text = Convert.ToString(P_idVibrato);
        }

        public void On_btnEditer_Click(object P_Sender, EventArgs P_Arg)
        {
            Task.Factory.StartNew(() =>
            {
                if (entNomVibrato.Text != "" && entModeleVibrato.Text != "" && entMarqueVibrato.Text != "" && entStockMicro.Text != "")
                {
                    Le_WS.Edit_Vibrato(Int32.Parse(lbIdVibrato.Text), entNomVibrato.Text, entModeleVibrato.Text, entMarqueVibrato.Text, Int32.Parse(entStockMicro.Text));
                    Navigation.PopAsync();
                }
            });
        }
    }
}
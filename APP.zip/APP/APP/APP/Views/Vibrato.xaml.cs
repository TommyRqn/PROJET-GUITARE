﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Vibrato : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);

        static List<NS_WS.C_VIBRATO> Les_Vibratos = new List<NS_WS.C_VIBRATO>();

        public Vibrato()
        {
            InitializeComponent();

            foreach (NS_WS.C_VIBRATO item in Le_WS.Get_All_Vibrato())
            {
                Les_Vibratos.Add(item);
            }

            Task.Factory.StartNew(() =>
            {
                ListeVibrato.ItemsSource = Les_Vibratos;
            });
        }

        public void On_btnAjoutVibrato_Click(object P_Sender, EventArgs P_Arg)
        {
            if (entNomVibrato.Text != "" && entModeleVibrato.Text != "" && entMarqueVibrato.Text != "" && entStockMicro.Text != "")
            {
                ListeVibrato.ItemsSource = null;
                Les_Vibratos.Clear();
                Le_WS.Add_Vibrato(entNomVibrato.Text, entModeleVibrato.Text, entMarqueVibrato.Text, Int32.Parse(entStockMicro.Text));

                foreach (NS_WS.C_VIBRATO item in Le_WS.Get_All_Vibrato())
                {
                    Les_Vibratos.Add(item);
                }
                ListeVibrato.ItemsSource = Les_Vibratos;
            }
            entNomVibrato.Text = null;
            entModeleVibrato.Text = null;
            entMarqueVibrato.Text = null;
            entStockMicro.Text = null;
        }

        private async void OnItemSelected(Object sender, ItemTappedEventArgs e)
        {
            var details = e.Item as NS_WS.C_VIBRATO;
            await Navigation.PushAsync(new DetailVibrato(details.idVibrato, details.Nom, details.Modele, details.Marque, Convert.ToString(details.Stock)));
        }

        public void RefreshView(System.Object sender, System.EventArgs e)
        {
            ICommand refreshCommand = new Command(() =>
            {
                // IsRefreshing is true
                // Refresh data here
                ListeVibrato.ItemsSource = null;
                Les_Vibratos.Clear();

                foreach (NS_WS.C_VIBRATO item in Le_WS.Get_All_Vibrato())
                {
                    Les_Vibratos.Add(item);
                }
                ListeVibrato.ItemsSource = Les_Vibratos;

                rView.IsRefreshing = false;
            });
            rView.Command = refreshCommand;
        }
    }
}
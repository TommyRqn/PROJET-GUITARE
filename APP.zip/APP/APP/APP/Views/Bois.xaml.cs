﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace APP.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Bois : ContentPage
    {
        static NS_WS.WebServiceSoapClient Le_WS = new NS_WS.WebServiceSoapClient(NS_WS.WebServiceSoapClient.EndpointConfiguration.WebServiceSoap12);
        static List<NS_WS.C_BOIS> Les_Bois = new List<NS_WS.C_BOIS>();

        public Bois()
        {
            InitializeComponent();

            foreach (NS_WS.C_BOIS item in Le_WS.Get_All_Bois())
            {
                Les_Bois.Add(item);
            }

            Task.Factory.StartNew(() =>
            {
                ListeBois.ItemsSource = Les_Bois;
            });
        }

        public void On_btnAjoutBois_Click(object P_Sender, EventArgs P_Arg)
        {
            if (entNomBois.Text != "" && entOrigineBois.Text != "" && entStockBois.Text != "")
            {
                ListeBois.ItemsSource = null;
                Les_Bois.Clear();
                Le_WS.Add_Bois(entNomBois.Text, entOrigineBois.Text, Int32.Parse(entStockBois.Text));

                foreach (NS_WS.C_BOIS item in Le_WS.Get_All_Bois())
                {
                    Les_Bois.Add(item);
                }

                ListeBois.ItemsSource = Les_Bois;
            }
            entNomBois.Text = null;
            entOrigineBois.Text = null;
            entStockBois.Text = null;
        }

        private async void OnItemSelected(Object sender, ItemTappedEventArgs e)
        {
            var details = e.Item as NS_WS.C_BOIS;
            await Navigation.PushAsync(new DetailBois(details.idBois, details.Nom, details.Origine, Convert.ToString(details.Stock)));
        }

        public void RefreshView(System.Object sender, System.EventArgs e)
        {
            ICommand refreshCommand = new Command(() =>
            {
                // IsRefreshing is true
                // Refresh data here
                ListeBois.ItemsSource = null;
                Les_Bois.Clear();

                foreach (NS_WS.C_BOIS item in Le_WS.Get_All_Bois())
                {
                    Les_Bois.Add(item);
                }
                ListeBois.ItemsSource = Les_Bois;

                rView.IsRefreshing = false;
            });
            rView.Command = refreshCommand;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WS_GUITARE
{
    /// <summary>
    /// Description résumée de WebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Pour autoriser l'appel de ce service Web depuis un script à l'aide d'ASP.NET AJAX, supprimez les marques de commentaire de la ligne suivante. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService : System.Web.Services.WebService
    {

        C_BASE La_Base = new C_BASE();

        [WebMethod]
        public void Add_Guitare(string P_Nom, int P_idMicrophoneNeck, int P_idMicrophoneCentrale, int P_Vibrato, int P_Client, int P_idMicrophoneBridge, int P_idBoisManche, int P_idBoisCorps, int P_idBoisTouche)
        {
            La_Base.Add_Guitare(P_Nom, P_idMicrophoneNeck, P_idMicrophoneCentrale, P_Vibrato, P_Client, P_idMicrophoneBridge, P_idBoisManche, P_idBoisCorps, P_idBoisTouche);
        }

        [WebMethod]
        public void Add_Guitare_No_Neck(string P_Nom, int P_idMicrophoneCentrale, int P_Vibrato, int P_Client, int P_idMicrophoneBridge, int P_idBoisManche, int P_idBoisCorps, int P_idBoisTouche)
        {
            La_Base.Add_Guitare_No_Neck(P_Nom, P_idMicrophoneCentrale, P_Vibrato, P_Client, P_idMicrophoneBridge, P_idBoisManche, P_idBoisCorps, P_idBoisTouche);
        }

        [WebMethod]
        public void Add_Guitare_No_Centrale(string P_Nom, int P_idMicrophoneNeck, int P_Vibrato, int P_Client, int P_idMicrophoneBridge, int P_idBoisManche, int P_idBoisCorps, int P_idBoisTouche)
        {
            La_Base.Add_Guitare_No_Centrale(P_Nom, P_idMicrophoneNeck, P_Vibrato, P_Client, P_idMicrophoneBridge, P_idBoisManche, P_idBoisCorps, P_idBoisTouche);
        }

        [WebMethod]
        public void Add_Guitare_No_Bridge(string P_Nom, int P_idMicrophoneNeck, int P_idMicrophoneCentrale, int P_Vibrato, int P_Client, int P_idBoisManche, int P_idBoisCorps, int P_idBoisTouche)
        {
            La_Base.Add_Guitare_No_Bridge(P_Nom, P_idMicrophoneNeck, P_idMicrophoneCentrale, P_Vibrato, P_Client, P_idBoisManche, P_idBoisCorps, P_idBoisTouche);
        }

        [WebMethod]
        public void Add_Client(string P_Nom, string P_Prenom, string P_Adresse, string P_MotDePasse, string P_Telephone, string P_Email)
        {
            La_Base.Add_Client(P_Nom, P_Prenom, P_Adresse, P_MotDePasse, P_Telephone, P_Email);
        }

        [WebMethod]
        public void Add_Bois(string P_Nom, string P_Origine, int P_Stock)
        {
            La_Base.Add_Bois(P_Nom, P_Origine, P_Stock);
        }

        [WebMethod]
        public void Add_Microphone(string P_Nom, string P_ReferenceConstructeur, string P_Marque, int P_Stock)
        {
            La_Base.Add_Microphone(P_Nom, P_ReferenceConstructeur, P_Marque, P_Stock);
        }

        [WebMethod]
        public void Add_Vibrato(string P_Nom, string P_Modele, string P_Marque, int P_Stock)
        {
            La_Base.Add_Vibrato(P_Nom, P_Modele, P_Marque, P_Stock);
        }

        [WebMethod]
        public List<C_CLIENT> Login(string P_Email, string P_Password)
        {
            return La_Base.Login(P_Email, P_Password).ToList();
        }

        [WebMethod]
        public List<C_GUITARE> Get_All_Guitare()
        {
            return La_Base.Get_All_Guitare().ToList();
        }

        [WebMethod]
        public List<C_CLIENT> Get_All_Client()
        {
            return La_Base.Get_All_Client().ToList();
        }

        [WebMethod]
        public List<C_BOIS> Get_All_Bois()
        {
            return La_Base.Get_All_Bois().ToList();
        }

        [WebMethod]
        public List<C_VIBRATO> Get_All_Vibrato()
        {
            return La_Base.Get_All_Vibrato().ToList();
        }

        [WebMethod]
        public List<C_MICROPHONE> Get_All_Microphone()
        {
            return La_Base.Get_All_Microphone().ToList();
        }

        [WebMethod]
        public List<C_GUITARE> Get_Guitare_Nom_Prenom(string P_Nom, string P_Prenom)
        {
            return La_Base.Get_Guitare_By_Nom_Prenom(P_Prenom, P_Nom).ToList();
        }

        [WebMethod]
        public List<C_GUITARE> Get_Guitare_By_Client_Id(int P_Id)
        {
            return La_Base.Get_Guitare_By_Client_Id(P_Id).ToList();
        }

        [WebMethod]
        public List<C_CLIENT> Get_Client_By_Id(int P_Id)
        {
            return La_Base.Get_Client_By_Id(P_Id).ToList();
        }

        [WebMethod]
        public List<C_MICROPHONE> Get_Microphone_By_Id(int P_Id)
        {
            return La_Base.Get_Microphone_By_Id(P_Id).ToList();
        }

        [WebMethod]
        public List<C_BOIS> Get_Bois_By_Id(int P_Id)
        {
            return La_Base.Get_Bois_By_Id(P_Id).ToList();
        }

        [WebMethod]
        public List<C_VIBRATO> Get_Vibrato_By_Id(int P_Id)
        {
            return La_Base.Get_Vibrato_By_Id(P_Id).ToList();
        }

        [WebMethod]
        public void Delete_Bois_By_Id(int P_Id)
        {
            La_Base.Delete_Bois_By_Id(P_Id);
        }

        [WebMethod]
        public void Delete_Vibrato_By_Id(int P_Id)
        {
            La_Base.Delete_Vibrato_By_Id(P_Id);
        }

        [WebMethod]
        public void Delete_Microphone_By_Id(int P_Id)
        {
            La_Base.Delete_Microphone_By_Id(P_Id);
        }

        [WebMethod]
        public void Edit_Bois(int P_Id, string P_Nom, string P_Origine, int P_Stock)
        {
            La_Base.Edit_Bois(P_Id, P_Nom, P_Origine, P_Stock);
        }

        [WebMethod]
        public void Edit_Microphone(int P_Id, string P_Nom, string P_Reference, string P_Marque, int P_Stock)
        {
            La_Base.Edit_Microphone(P_Id, P_Nom, P_Reference, P_Marque, P_Stock);
        }

        [WebMethod]
        public void Edit_Vibrato(int P_Id, string P_Nom, string P_Modele, string P_Marque, int P_Stock)
        {
            La_Base.Edit_Vibrato(P_Id, P_Nom, P_Modele, P_Marque, P_Stock);
        }

        [WebMethod]
        public string Get_Time()
        {
            return DateTime.Now.ToString();
        }
    }
}
